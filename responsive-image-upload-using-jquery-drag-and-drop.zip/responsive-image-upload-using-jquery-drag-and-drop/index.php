<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Responsive Image Uploade using jQuery Drag and Drop</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<script src="jquery-3.2.1.min.js"
    type="text/javascript"></script>
<script>
$(document).ready(function() {
	$("#drop-container").on('dragenter', function (e){
	e.preventDefault();
	$(this).css('border', '#39b311 2px dashed');
	$(this).css('background', '#f1ffef');
	});


	$("#drop-container").on('dragover', function (e){
	e.preventDefault();
	});

	$("#drop-container").on('drop', function (e){
	$(this).css('border', '#07c6f1 2px dashed');
	$(this).css('background', '#FFF');
    e.preventDefault();
	var image = e.originalEvent.dataTransfer.files;
	createFormData(image);
	});
});

function createFormData(image) {
	var formImage = new FormData();
	formImage.append('dropImage', image[0]);
	uploadFormData(formImage);
}

function uploadFormData(formData) {
	$.ajax({
	url: "upload.php",
	type: "POST",
	data: formData,
	contentType:false,
	cache: false,
	processData: false,
	success: function(response){
        var imagePreview = $(".drop-image").clone();
        imagePreview.attr("src", response); 
        imagePreview.removeClass("drop-image");
		imagePreview.addClass("preview");
        $('#drop-container').append(imagePreview);
	}
});
}
</script>
</head>
<body>
    <div id="drop-container">
        <div class="drop-area-text">Drag and Drop Images Here</div>
    </div>
    <img src="" class="drop-image" />

</body>
</html>