<?php
if (is_array($_FILES)) {
    if (is_uploaded_file($_FILES['dropImage']['tmp_name'])) {
        $sourcePath = $_FILES['dropImage']['tmp_name'];
        $targetPath = "images/" . $_FILES['dropImage']['name'];
        if (move_uploaded_file($sourcePath, $targetPath)) {
            print $targetPath;
        }
    }
}
?>