<!DOCTYPE html>
<html>
  <head>
   <title>Category</title>
    <?php 
      include('links.php');
    ?>
  </head>
  <body>
    <!-- navbar-->
   <?php 
      include('header.php');
      include('conn.php');
    ?>
    <div class="d-flex align-items-stretch">
      <?php 
      include('sidebar.php');
    ?>
    <?php 
      if ($_SERVER['REQUEST_METHOD'] == 'POST'){
        $name=$_POST['pname'];
        $dsc=$_POST['pdsc'];
        $price=$_POST['pprice'];

        $filePath="images/".$_FILES["img"]["name"];

        $pcat='';
        foreach ($_POST['category'] as $select)
        {
          $pcat=$select; // Displaying Selected Value
        }
        $query=("INSERT INTO products values('','$pcat','$name','$dsc','$price','$filePath')");
        $result=mysqli_query($con,$query);
        if($result){
          ?>
            <script>
              alert('Product add successfully!');
              window.location.href='form.php';
            </script>
          <?php
      }
      else{
        ?>
            <script>
              alert('Data not inserted!');
              window.location.href='form.php';
            </script>
          <?php
        
      }
    }
    else{
    ?>
      <div class="page-holder w-100 d-flex flex-wrap">
        <div class="container-fluid px-xl-5">
          <section class="py-5">
            <div class="row">
              
              
              <!-- Form Elements -->
              <div class="col-lg-12 mb-5">
                <div class="card">
                  <div class="card-header">
                    <h3 class="h6 text-uppercase mb-0">Product Form</h3>
                  </div>
                  <div class="card-body">
                    <form class="form-horizontal" method="post" action="form.php" enctype="multipart/form-data">
                      <div class="form-group row">
                        <label class="col-md-3 form-control-label">Product Name</label>
                        <div class="col-md-9">
                          <input type="text" name="pname" class="form-control">
                        </div>
                      </div>
                      <div class="line"></div>
                      <div class="form-group row">
                        <label class="col-md-3 form-control-label">Product Description</label>
                        <div class="col-md-9">
                          <input type="text" name="pdsc" class="form-control"><small class="form-text text-muted ml-3">Write a short description about product.</small>
                        </div>
                      </div>
                      <?php 
                        
                        
                      ?>
                      <div class="line"></div>
                      <div class="form-group row">
                        <label class="col-md-3 form-control-label">Select Category</label>
                        <div class="col-md-9 select mb-3">
                          <select name="category[]" class="form-control">
                            <?php
                            $sql="select * from categories";
                             $res=mysqli_query($con,$sql);
                              while($row=mysqli_fetch_assoc($res)){
                                  ?>
                                    <option value="<?php echo $row['cat_id'] ?>"><?php echo $row['cat_name'] ?></option>
                                  <?php
                               }
                             ?>
                            
                            
                          </select>
                        </div>
                        
                      </div>

                      <div class="line"></div>
                      <div class="form-group row">
                        <label class="col-md-3 form-control-label">Price</label>
                        <div class="col-md-9">
                          <input type="text" name="pprice" class="form-control">
                        </div>
                      </div>
                      <div class="line"></div>
                      <div class="form-group row">
                        <label class="col-md-3 form-control-label">Chose Image</label>
                        <div class="col-md-9">
                          <input type="file" name="img" class="form-control">
                        </div>
                      </div>

                      
                      <div class="line"></div>
                      <div class="form-group row">
                        <div class="col-md-9 ml-auto">
                          <button type="submit" class="btn btn-secondary">Cancel</button>
                          <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
             
            </div>
          </section>
        </div>
        <footer class="footer bg-white shadow align-self-end py-3 px-xl-5 w-100">
          <div class="container-fluid">
            <div class="row">
              <div class="col-md-6 text-center text-md-left text-primary">
                <p class="mb-2 mb-md-0">JH IT ZONE &copy; 2018-2020</p>
              </div>
              <div class="col-md-6 text-center text-md-right text-gray-400">
                <p class="mb-0">Design by <a href="#" class="external text-gray-400">ABID HUSSAIN & JH IT ZONE TEAM</a></p>
                <!-- Please do not remove the backlink to us unless you support further theme's development at https://bootstrapious.com/donate. It is part of the license conditions. Thank you for understanding :)-->
              </div>
            </div>
          </div>
        </footer>
      </div>
    <?php
  }

    ?>
      
    </div>
    <!-- JavaScript files-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper.js/umd/popper.min.js"> </script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/js-cookie@2/src/js.cookie.min.js"></script>
    <script src="js/front.js"></script>
  </body>
</html>