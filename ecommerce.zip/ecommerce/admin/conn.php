<?php 
	$con=mysqli_connect('localhost','root','','commerce');
	if (!$con) {
		echo "Database connection fail";
	}
?>