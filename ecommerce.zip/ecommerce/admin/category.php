

<!DOCTYPE html>
<html>
  <head>
   <title>Category</title>
    <?php 
      include('links.php');
    ?>
  </head>
  <body>
    <!-- navbar-->
   <?php 
      include('conn.php');
      include('header.php');
    ?>
    <div class="d-flex align-items-stretch">
      <?php 
      include('sidebar.php');
    ?>
    <?php
      if ($_SERVER['REQUEST_METHOD'] == 'POST'){
        $name=$_POST['cname'];
        $query=("INSERT INTO categories values('','$name')");
        $result=mysqli_query($con,$query);
        if($result){
          ?>
            <script>
              alert('Category add successfully!');
              window.location.href='category.php';
            </script>
          <?php
      }
      else{
        ?>
            <script>
              alert('Data not inserted!');
              window.location.href='category.php';
            </script>
        <?php
      }
    }
    else{
    ?>
       <div class="page-holder w-100 d-flex flex-wrap">
        <div class="container-fluid px-xl-5">
          <section class="py-5">
            <div class="row">
              
              
              <!-- Horizontal Form-->
              <div class="offset-2 col-lg-6 mb-5">
                <div class="card" style="width: 130%;">
                  <div class="card-header">
                    <h3 class="h6 text-uppercase mb-0">Category Form</h3>
                  </div>
                  <div class="card-body">
                    <p>Add your category that you want to display on user side.</p>
                    <form class="form-horizontal" action="category.php" method="post">
                      <div class="form-group row">
                        <label class="col-md-3 form-control-label">Category</label>
                        <div class="col-md-8">
                          <input id="inputHorizontalSuccess" type="text" placeholder="Category Name" name="cname" class="form-control form-control-success"><small class="form-text text-muted ml-3">Write category name.</small>
                        </div>
                      </div>
                      
                      <div class="form-group row">
                        <div class="col-md-9 ml-auto">
                          <button type="submit" class="btn btn-secondary">Cancel</button>
                          <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
             
            </div>
          </section>
        </div>
        <footer class="footer bg-white shadow align-self-end py-3 px-xl-5 w-100">
          <div class="container-fluid">
            <div class="row">
              <div class="col-md-6 text-center text-md-left text-primary">
                <p class="mb-2 mb-md-0">JH IT ZONE &copy; 2018-2020</p>
              </div>
              <div class="col-md-6 text-center text-md-right text-gray-400">
                <p class="mb-0">Design by <a href="#" class="external text-gray-400">ABID HUSSAIN & JH IT ZONE TEAM</a></p>
                <!-- Please do not remove the backlink to us unless you support further theme's development at https://bootstrapious.com/donate. It is part of the license conditions. Thank you for understanding :)-->
              </div>
            </div>
          </div>
        </footer>
      </div>


    <?php
  }

     ?>
     
    </div>
    <!-- JavaScript files-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper.js/umd/popper.min.js"> </script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/js-cookie@2/src/js.cookie.min.js"></script>
    <script src="js/front.js"></script>
  </body>
</html>