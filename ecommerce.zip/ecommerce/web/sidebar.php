<div id="sidebar" class="sidebar py-3">
        <div class="text-gray-400 text-uppercase px-3 px-lg-4 py-4 font-weight-bold small headings-font-family">MAIN</div>
        <ul class="sidebar-menu list-unstyled">
              
              <li class="sidebar-list-item"><a href="index.php" class="sidebar-link text-muted"><i class="o-sales-up-1 mr-3 text-gray"></i><span>Category</span></a></li>
              <li class="sidebar-list-item"><a href="rating.php" class="sidebar-link text-muted"><i class="o-home-1 mr-3 text-gray"></i><span>Products</span></a></li>

              <li class="sidebar-list-item"><a href="login.php" class="sidebar-link text-muted"><i class="o-sales-up-1 mr-3 text-gray"></i><span>Login</span></a></li>
              <li class="sidebar-list-item"><a href="logout.php" class="sidebar-link text-muted"><i class="o-home-1 mr-3 text-gray"></i><span>Logout</span></a></li>
               
              
        </ul>
        
      </div>