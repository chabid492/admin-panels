<!DOCTYPE html>
<html>
  <head>
    <title>Login</title>
    <?php
    include('links.php');
    include('conn.php');
    session_start();
    ?>
  </head>
  <body>
    <?php
    if (isset($_POST['email']) && isset($_POST['password'])) {
        
        $email=$_POST['email'];
        $pass=$_POST['password'];
        
        $query="SELECT * FROM user where email='$email'";
        $sql=mysqli_query($con,$query);
        if ($sql) {
          
          $row=mysqli_fetch_array($sql);
          if ($email==$row['email'] && $pass==$row['password']) {
            $_SESSION['uid']=$row['id'];
            $_SESSION['uemail']=$row['email'];
            $_SESSION['upassword']=$row['password'];
            
            header("location:rating.php");
          }
          else{ 
            header("location:login.php");
          }
          

        }
        else{

          header("location:login.php"); 
        }
      
    }
    else{
    ?>
    <div class="page-holder d-flex align-items-center">
      <div class="container">
        <div class="row align-items-center py-5">
          <div class="col-5 col-lg-7 mx-auto mb-5 mb-lg-0">
            <div class="pr-lg-5"><img src="img/illustration.svg" alt="" class="img-fluid"></div>
          </div>
          <div class="col-lg-5 px-lg-4">
            <h1 class="text-base text-primary text-uppercase mb-4">E-commerce Managment System</h1>
            <div class="d-flex justify-content-around">
              <h2 class="mb-4">Welcome back!</h2>
              <a href="index.php" class="btn btn-info">Home</a>
            </div>
            <p class="text-muted">Give your email and password for login.</p>
            <form id="loginForm" action="login.php" method="post" class="mt-4">
              <div class="form-group mb-4">
                <input type="email" name="email" placeholder="Email address" class="form-control border-0 shadow form-control-lg">
              </div>
              <div class="form-group mb-4">
                <input type="password" name="password" placeholder="Password" class="form-control border-0 shadow form-control-lg text-violet">
              </div>
              
              <div class="d-flex justify-content-around">
                <button type="submit" class="btn btn-primary shadow px-5">Log in</button>
                <a href="register.php" class="btn btn-info">Register</a>
              </div>
            </form>
          </div>
        </div>
        <p class="mt-5 mb-0 text-gray-400 text-center">Design by <a href="#" class="external text-gray-400">Abid Hussain</a> & JH IT ZONE TEAM</p>
        
      </div>
    </div>
    <?php
    }
    ?>
    <!-- JavaScript files-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper.js/umd/popper.min.js"> </script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/js-cookie@2/src/js.cookie.min.js"></script>
    <script src="js/front.js"></script>
  </body>
</html>