<?php

$product_id = $_POST["product_id"];
$user_id = $_POST["user_id"];
$ratings = $_POST["ratings"];

$conn = mysqli_connect("localhost", "root", "", "commerce");

$query="SELECT * FROM ratings where user_id='$user_id' AND pro_id='$product_id'";
$result=mysqli_query($conn,$query);
if ($row=mysqli_fetch_assoc($result) > 0) {
	echo 'Sory! You have alredy given rating.';
}
else {
	$res=mysqli_query($conn, "INSERT INTO ratings VALUES ('','$product_id','$user_id', '$ratings')");
	if ($res) {
		echo "Rating submited!";
	}
	else{
		echo "Error";
	}
}

	


?>