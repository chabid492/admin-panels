<!DOCTYPE html>
<html>
  <head>
    <title>Home</title>
    <?php 
      include('links.php');
      include('conn.php');
    ?>

    <style type="text/css" media="screen">
      .cardShow{
        position: absolute; top: 0; left: 0; background: gray; height:100%; width: 100%;
        opacity: 0;
        transition: 1s all;
      }
      .cardShow:hover{
        opacity: 0.8;
        transition: 1s all;
      }
      .linkof{
        align-items: center; text-align: center;color: #ffffff;font-size:24px;
      }
    </style>
  </head>
  <body>
    <!-- navbar-->
    <?php 
      include('header.php');
    ?>
    <div class="d-flex align-items-stretch">
      <?php 
      include('sidebar.php');
    ?>
    
      <div class="page-holder w-100 d-flex flex-wrap">
        <div class="container-fluid px-xl-5"> 
          <section class="py-5">
            <h2>Categories</h2>
            <div class="row text-dark">
              <?php
                $query="SELECT  * FROM 
                      Categories
                  INNER JOIN 
                      products 
                  ON
                      Categories.cat_id=products.cat_id
                       group by products.cat_id";
                $sql=mysqli_query($con,$query);
                if (!$sql) {
                  echo 'Record not found';
                }
                

               ?>
               <?php 
                   $chk='';
                   $flag=false;
                  while ($row=mysqli_fetch_assoc($sql)) {

                      if ($chk==$row['cat_id']) {
                          $flag=true;
                        ?>
                        

                        <?php
                      }
                      else{
                        $flag=false;
                        ?>
                           <div class="col-lg-4 mb-4 mb-lg-0">
                            <div style="position: relative;" class="card rounded credit-card bg-hover-gradient-violet">
                              <div class="content d-flex flex-column justify-content-center">
                               
                                 <?php 
                                    echo "<img src=".$row['pimg']." width=100%>";
                                 ?>
                               
                                 
                              </div>
                              <div class="cardShow">
                                  <div class="content d-flex flex-column justify-content-center">
                                  
                                  <?php
                                    echo "<a href=rating.php?catId=".$row['cat_id']." class='linkof'>".$row['cat_name']."</a>";
                                   ?>
                                </div>
                              </div>
                            </div>
                          </div>
                        <?php
                      }
                      $chk=$row['cat_id'];
                  }
                  $chk='';

               ?>
             
            </div>
          </section>
          
        
        </div>
        <footer class="footer bg-white shadow align-self-end py-3 px-xl-5 w-100">
          <div class="container-fluid">
            <div class="row">
              <div class="col-md-6 text-center text-md-left text-primary">
                <p class="mb-2 mb-md-0">JH IT ZONE &copy; 2018-2020</p>
              </div>
              <div class="col-md-6 text-center text-md-right text-gray-400">
                <p class="mb-0">Design by <a href="#" class="external text-gray-400">ABID HUSSAIN & JH IT ZONE TEAM</a></p>
                <!-- Please do not remove the backlink to us unless you support further theme's development at https://bootstrapious.com/donate. It is part of the license conditions. Thank you for understanding :)-->
              </div>
            </div>
          </div>
        </footer>
      </div>
    </div>
    <!-- JavaScript files-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper.js/umd/popper.min.js"> </script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/js-cookie@2/src/js.cookie.min.js"></script>
    <script src="js/charts-home.js"></script>
    <script src="js/front.js"></script>
  </body>
</html>