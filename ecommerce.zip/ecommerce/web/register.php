<!DOCTYPE html>
<html>
  <head>
    <title>Register</title>
    <?php 
      include('links.php');
      include('conn.php');
    ?>
    <?php 
      if ($_SERVER['REQUEST_METHOD']=='POST') {
          if (isset($_POST['submit'])=='' && isset($_POST['submit'])=='') {
            $email=$_POST['email'];
            $pass=$_POST['password'];
            $query="INSERT INTO user values('','$email','$pass')";
            $sql=mysqli_query($con,$query);
            if ($sql) {
              header("location:login.php");
            }
            else {
              echo '<script>alert("Data not insert")</script>';
            }
          }
          else{
            echo '<script>alert("Please fill all fields")
                  window.location.href="register.php";
            </script>';

          }
      }
    ?>
  </head>
  <body>
    <div class="page-holder d-flex align-items-center">
      <div class="container">
        <div class="row align-items-center py-5">
          <div class="col-5 col-lg-7 mx-auto mb-5 mb-lg-0">
            <div class="pr-lg-5"><img src="img/illustration.svg" alt="" class="img-fluid"></div>
          </div>
          <div class="col-lg-5 px-lg-4">
            <h1 class="text-base text-primary text-uppercase mb-4">E-commerce Managment System</h1>
            <div class="d-flex justify-content-around">
              <h2 class="mb-4">Welcome back!</h2>
              <a href="index.php" class="btn btn-info">Home</a>
            </div>
            <p class="text-muted">Give your email and password for Registration.</p>
            <form id="loginForm" action="" method="post" class="mt-4">
              <div class="form-group mb-4">
                <input type="text" name="email" placeholder="Email address" class="form-control border-0 shadow form-control-lg">
              </div>
              <div class="form-group mb-4">
                <input type="password" name="password" placeholder="Password" class="form-control border-0 shadow form-control-lg text-violet">
              </div>
              
              <button type="submit" name="submit" class="btn btn-primary shadow px-5">Register</button>
            </form>
          </div>
        </div>
        <p class="mt-5 mb-0 text-gray-400 text-center">Design by <a href="#" class="external text-gray-400">Abid Hussain</a> & JH IT ZONE TEAM</p>
        
      </div>
    </div>
    <!-- JavaScript files-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper.js/umd/popper.min.js"> </script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/js-cookie@2/src/js.cookie.min.js"></script>
    <script src="js/front.js"></script>
  </body>
</html>