<!DOCTYPE html>
<html>
	<head>
		<title>Rating star</title>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.2.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/starrr.css">
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
		<script src="js/starrr.js"></script>
	</head>
	<body>
		<div class="container-fluid mt-3">
			
			<?php
				// Connecting with database
				$conn = mysqli_connect("localhost", "root", "", "commerce");
				// Getting all products
				$result = mysqli_query($conn, "SELECT * FROM products");
			?>
			<div class="row">
				<?php
						// Displaying each product
				while ($row = mysqli_fetch_object($result)) {
					// Getting ratings of current product using ID
					$id=$row->pro_id;

					$result_ratings = mysqli_query($conn, "SELECT * FROM ratings WHERE pro_id ='$id'");
					// Adding total ratings from each user
					$ratings = 0;
					while ($row_ratings = mysqli_fetch_object($result_ratings))
					{
						$ratings += $row_ratings->value;
					}

					// Calculating average from all ratings
					$average_ratings = 0;
					if ($ratings > 0)
					{
						$average_ratings = round($ratings / mysqli_num_rows($result_ratings),1);
					}


				?>
				<div class="col-md-4 text-center mb-3" >
					<div class="p-3" style="box-shadow: 0px 2px 5px darkorange;">
						<div class="d-flex justify-content-between">
							<h4>
							<?php
								echo $row->pname;
							?>
						    </h4>
						    <span>PKR: 
						    	<?php
								echo $row->pprice;
							    ?>
						    </span>
						</div>
						<div class="d-flex flex-row justify-content-end">
							<div class="ratings" data-rating="<?php echo $average_ratings; ?>">
							
							</div>
							<span class="ml-1" style="font-weight: bold; color: orange;"><?php echo $average_ratings; ?></span>
						</div>
						<img src="<?php echo $row->pimg; ?>" alt="" width="50%">
						<form method="POST" onsubmit="return saveRatings(this);">
							<input type="hidden" name="product_id" value="<?php echo $row->pro_id; ?>">
							<div class="starrr"></div>
							<input type="submit" class="btn btn-info btn-small" value="Submit">
						</form>
						
					</div>
				</div>
				<?php
					}
				?>
			</div>
			<?php
			?>
		</div>
		<script>
			$(function () {
				$(".starrr").starrr();
			});

			var ratings = 0;
			$(function () {
				$(".starrr").starrr().on("starrr:change", function (event, value) {
					ratings = value;
				});
			});

			function saveRatings(form) {
				var product_id = form.product_id.value;

				$.ajax({
					url: "save-ratings.php",
					method: "POST",
					data: {
						"product_id": product_id,
						"ratings": ratings
					},
					success: function (response) {
						// whatever server echo, that will be displayed here in alert
						alert(response);
					}
				});

				return false;
			}

			// Getting all div with ratings class
			var rating = document.getElementsByClassName("ratings");

			// Loop through all divs
			for (var a = 0; a < rating.length; a++)
			{

				// Display star on each div based on data-rating attribute value
				// readOnly will prevent the user changing it's value
				$(rating[a]).starrr({
					readOnly: true,
					rating: rating[a].getAttribute("data-rating")
				});
			}
		</script>
	</body>
</html>