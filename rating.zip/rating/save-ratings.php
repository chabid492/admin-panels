<?php

$product_id = $_POST["product_id"];
$ratings = $_POST["ratings"];

$conn = mysqli_connect("localhost", "root", "", "commerce");

mysqli_query($conn, "INSERT INTO ratings VALUES ('','$product_id', '$ratings')");

// whatever you echo here, will be displayed in alert on user side
echo "Saved";
