-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 04, 2020 at 11:59 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `commerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(255) NOT NULL,
  `cat_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_name`) VALUES
(1, 'Laptop'),
(2, 'LCD'),
(3, 'Mobile');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `pro_id` int(255) NOT NULL,
  `cat_id` varchar(255) NOT NULL,
  `pname` varchar(255) NOT NULL,
  `pdesc` varchar(255) NOT NULL,
  `pprice` varchar(255) NOT NULL,
  `pimg` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`pro_id`, `cat_id`, `pname`, `pdesc`, `pprice`, `pimg`) VALUES
(1, '1', 'appleMacBook', 'The new MacBook Air MQD32 2017 comes equipped with an 8GB DDR3 RAM Apart from the Processor RAM plays an important part in how ', '150000', 'images/appleMacBook.jpg'),
(2, '3', 'OppoA3s', 'Oppo A3s price in Pakistan starts at Rs. 18,999. This is for the base variant that comes with 2GB of RAM and 16GB of internal storage.\r\n\r\nRetail Price of Oppo A3s in Pakistan is Rs. 18,999.\r\nRetail Price of Oppo in USD is $142.', '25000', 'images/oppoA3s.png'),
(3, '2', 'Samsung UA24H4100AR', 'Samsung?s newest Touch of Color design is sure to command attention. Upholding Samsung?s ToC design legacy, the SD390 was crafted to catch the light of its surroundings', '35000', 'images/samsunglcd.png'),
(4, '3', 'Galaxy S8 ', '*Infinity Display: a bezel-less, full-frontal, edge-to-edge screen. *Default resolution is Full HD+ and can be changed to Quad HD+(WQHD+) in Settings. *Screen measured diagonally as a full rectangle without accounting for the rounded corners.', '37000', 'images/samsung.png');

-- --------------------------------------------------------

--
-- Table structure for table `ratings`
--

CREATE TABLE `ratings` (
  `rat_id` int(255) NOT NULL,
  `pro_id` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ratings`
--

INSERT INTO `ratings` (`rat_id`, `pro_id`, `value`) VALUES
(1, '4', '5'),
(2, '4', '5'),
(3, '4', '4'),
(4, '4', '5'),
(5, '4', '3'),
(6, '3', '1'),
(7, '4', '4'),
(8, '2', '3'),
(9, '3', '5'),
(10, '2', '4'),
(11, '2', '1'),
(12, '2', '3'),
(14, '1', '3'),
(15, '1', '5'),
(16, '1', '4'),
(17, '1', '5'),
(18, '2', '3'),
(19, '2', '5'),
(20, '2', '1');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `rev_id` int(255) NOT NULL,
  `pro_id` varchar(255) NOT NULL,
  `review` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`rev_id`, `pro_id`, `review`) VALUES
(1, '1', 'Good'),
(2, '1', 'Good'),
(3, '3', 'Good'),
(4, '4', 'Good'),
(5, '2', 'Good'),
(6, '4', 'Good'),
(7, '4', 'Good'),
(8, '4', 'Good'),
(9, '4', 'Good'),
(10, '4', 'Good'),
(11, '4', 'Good'),
(12, '4', 'Good'),
(13, '4', 'Good'),
(14, '4', 'Good'),
(15, '3', 'Normal'),
(16, '4', 'Normal'),
(17, '2', 'Good'),
(18, '3', 'Good'),
(19, '2', 'Good'),
(20, '2', 'bad'),
(21, '2', 'Normal');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`pro_id`);

--
-- Indexes for table `ratings`
--
ALTER TABLE `ratings`
  ADD PRIMARY KEY (`rat_id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`rev_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `pro_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `ratings`
--
ALTER TABLE `ratings`
  MODIFY `rat_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `rev_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
