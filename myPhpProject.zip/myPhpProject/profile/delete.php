<?php
	include_once('conn.php');
	$id =$_GET['id'];
	echo $id;
	$query="DELETE FROM `details` WHERE id='$id'";
	$result=mysqli_query($con,$query);

	if ($result) {
	session_start();
	session_destroy();
	?>
		<script >
			alert('Record Deleted');
			window.location.href='home.php';
		</script>
	<?php
	
	}
	else {
		echo "Record not Delete";
	}
?>