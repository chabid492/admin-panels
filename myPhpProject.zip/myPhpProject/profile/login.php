<!DOCTYPE html>
<html>
	<head>
		<title>Login</title>
		<?php
			include_once('conn.php');
			include_once('links.php');
		?>

		<style type="text/css" media="screen">
			.myBtn{
				opacity: 0.3;
				transition: 0.8s;
				
			}
			.myBtnApply{
				opacity: 1;
				letter-spacing: 5px;
				font-size: 1.1rem;
				transition: 0.8s;
			}
		</style>
	</head>
	<body>
		
		<?php

			
			
			if ($_SERVER['REQUEST_METHOD']=='POST') {
				session_start();
				$email=$_POST['email'];
				$passSimple=$_POST['password'];
				$pass=md5($passSimple);

				$query="SELECT * FROM details where email='$email'";
				$sql=mysqli_query($con,$query);
				if ($sql) {
					
					$row=mysqli_fetch_array($sql);
					if ($email==$row['email'] && $pass==$row['password']) {
						$_SESSION['uemail']=$row['email'];
						$_SESSION['upassword']=$row['password'];
						$_SESSION['img']=$row['img'];
						$_SESSION['uid']=$row['id'];

						if (isset($_POST['remb'])) {
							setcookie('uemail',$_POST['email'],time()+3600);
							setcookie('upass',$_POST['password'],time()+3600);
						}
						/*else{
							setcookie('uemail',$_POST['email'],false);
							setcookie('upass',$_POST['password'],false);
						}*/
						
						header("location:home.php");
					}
					else{
						
						header("location:login.php");
					}
					

				}
				else{

					header("location:login.php");	
				}
			}
			else{
		?>
		<div class="container login-container">
			<div class="row">
				<div class="offset-3 col-md-6 login-form-1">
					<div class="d-flex flex-row justify-content-around">
						<h3>Login To Your Profile</h3>
						<a href="home.php" class="btn btn-primary">Back</a>
					</div>
					
					<form method="post" id="login_form">
						<div class="form-group">
							<input type="email" name="email" id="email" class="form-control" placeholder="Your Email *" value="<?php if(isset($_COOKIE["uemail"])) { echo $_COOKIE["uemail"]; } ?>" />
						</div>
						<div class="form-group">
							<input type="password" name="password" id="password" class="form-control" placeholder="Your Password *" value="<?php if(isset($_COOKIE["upass"])) { echo $_COOKIE["upass"]; } ?>" />
						</div>
						<div class="form-group form-check">
						    <label class="form-check-label">
						      <input class="form-check-input" type="checkbox" name="remb" value="1"> Remember me
						    </label>
						 </div>
						<div class="form-group">
							<div class="d-flex justify-content-start" style="align-items: center; ">
								<input type="submit"  id="submit" onclick="showHint()" disabled class="btnSubmit myBtn" value="Login"  />
								<a href="register.php" class="ForgetPwd" style="margin-left: 20px;">Have no account?</a>
							</div>
						</div>
						<div class="form-group">
							<div class="d-flex justify-content-center">
								<a href="" class="ForgetPwd">Forget Password</a>
							</div>
						</div>
					</form>
				</div>
				
			</div>
		</div>
		<?php
		}
		?>
		

		<!--script start-->
		<script>
			$flag=false;
			$flg=false;
			$('#email, #password, #login_form').on('keyup mouseover', function () {
				
				var pass=$('#password').val();
				var email=$('#email').val();
				if (pass.length >= '8' && email.length >= '8') {
						$flag=true;
						$flg=true;
				}
				else{
					$flag=false;
					$flg=false;
				}
				

				if ($flag!=true && $flg!=true) {
					$('.btnSubmit').addClass('myBtn').removeClass('myBtnApply');
				}
				else{
					$('.btnSubmit').removeAttr('disabled');
					$('.btnSubmit').removeClass('myBtn').addClass('myBtnApply');
				}
				
			});
		</script>
		<!--script end-->
	</body>
</html>