<!DOCTYPE html>
<html>
	<head>
		<title>Home</title>
		<?php
			include_once('conn.php');
			include_once('links.php');
		?>
		<style type="text/css" media="screen">
			.user_pic{
				width: 8%;
				border-radius: 5%;
			}
		</style>
	</head>
	<body>
		<!--navbar start-->
		<?php
			session_start();
					if (isset($_SESSION['uemail']) && isset($_SESSION['upassword'])) {
				
		?>
		<nav class="navbar navbar-icon-top navbar-expand-lg navbar-dark bg-dark">
			<a class="" href="#">
				<img src="<?php echo $_SESSION['img']; ?>" alt="user pic"  class="img-fluid user_pic">
			</a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navbarSupportedContent">
				
				
				<form class="form-inline my-2 my-lg-0 " style="flex-flow: nowrap;">
					<input class="form-control mr-sm-2" type="text" placeholder="Search" aria-label="Search">
					<button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
				</form>
			</div>
		</nav>
		<!--navbar end-->
		<!--main body-->
		<!--side navbar-->
		<div id="mySidenav" class="sidenav">
			<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
			<a href="update.php?id=<?php echo $_SESSION['uid']; ?>">Setting</a>
			<a href="logout.php">Logout</a>
		</div>
		<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776;</span>
		<!--side navbar end-->
		<!--user profile start-->
		<hr>
		<div class="container-fluid">
			<?php
				$email=$_SESSION['uemail'];
				$userQuery="select * from details where email='$email'";
				$userSql=mysqli_query($con,$userQuery);
				$userResult=mysqli_fetch_array($userSql);
			?>
			<div class="row">
				<div class="offset-3 col-sm-6">
					<h1 id="user_name">
					<?php
						
						echo $userResult['fname']." ".$userResult['lname'];
					?>
					</h1>
				</div>
				<div class="col-sm-2">
					<a href="#" class="pull-right"><img title="profile image" width="60%" class="img-circle img-responsive" src="<?php echo $userResult['img']; ?>"
					></a>
				</div>
			</div>
			
	<div class="d-flex justify-content-center">
		<?php
			$query="select * from details where email='$email'";
			$result=mysqli_query($con,$query);
			if ($result) {
			// output data of each row
			$row=mysqli_fetch_array($result);
		?>
		<table class="table table-striped w-50 " >
			<thead>
				<tr>
					<th>Properties</th>
					<th>Values</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td>First Name</td>
					<td><?php echo $row['fname']; ?></td>
				</tr>
				<tr>
					<td>Last Name</td>
					<td><?php echo $row['lname']; ?></td>
					
				</tr>
				<tr>
					<td>Date of Birth</td>
					<td><?php echo $row['bdate']; ?></td>
					
				</tr>
				<tr>
					<td>Cell</td>
					<td><?php echo $row['mno']; ?></td>
					
				</tr>
				<tr>
					<td>Email</td>
					<td><?php echo $row['email']; ?></td>
					
				</tr>
				<tr>
					<td>Image</td>
					<td>
						<img src="<?php echo $row['img']; ?>" width="80px">
					</td>
					
				</tr>
				<tr>
					<td >
						<a href="update.php?id=<?php echo $row['id']; ?>" ><span style="color: green;">Edit</span></a>
					</td>
					<td >
						<a href="delete.php?id=<?php echo $row['id']; ?>" onclick="showHint()"><span style="color: red;">Delete</span></a>
						<input type="hidden"  name="id" value="<?php echo $row['id']; ?>" id="stdId" class="form-control">
					</td>
					
				</tr>
			</tbody>
		</table>
		<?php
		}
		else {
		echo "No results found";
		}
		?>
		
	</div>
</div>
<!--/row-->
<!--user profile end-->
<!--main body-->
<?php
}
else{
?>
<nav class="navbar navbar-icon-top navbar-expand-lg navbar-dark bg-dark">
	<a class="navbar-brand" href="login.php">
		Profile
	</a>
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
	<span class="navbar-toggler-icon"></span>
	</button>
	<div class="collapse navbar-collapse" id="navbarSupportedContent">
		<ul class="navbar-nav mr-auto">
			<li class="nav-item active">
				<a class="nav-link" href="login.php">
					
					Home
					<span class="sr-only">(current)</span>
				</a>
			</li>
			
			
		</ul>
		<ul class="navbar-nav ">
			<li class="nav-item">
				<a class="nav-link" href="login.php">
					
					Login
				</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="register.php">
					
					Register
				</a>
			</li>
		</ul>
		<form class="form-inline my-2 my-lg-0">
			<input class="form-control mr-sm-2" type="text" placeholder="Search" aria-label="Search">
			<button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
		</form>
	</div>
</nav>
<!--navbar end-->
<!--main body-->
<div class="container">
	<div class="row">
		<div class="offset-3 col-lg-6">
			<div class="d-flex justify-content-center flex-column" style="align-items: center; height: 400px;">
				<h2 class="alert alert-danger ">Login First</h2>
				<p class="alert alert-warning">You are not login !</p>
			</div>
		</div>
	</div>
</div>
<!--main body-->
<?php
}
?>
<script>
	function openNav() {
	document.getElementById("mySidenav").style.width = "250px";
	}
	function closeNav() {
	document.getElementById("mySidenav").style.width = "0";
	}
</script>
</body>
</html>