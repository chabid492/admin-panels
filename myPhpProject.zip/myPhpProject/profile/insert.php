<?php 

include_once('conn.php');

$fname=$_REQUEST['fName'];
$lname=$_REQUEST['lName'];
$dob=$_REQUEST['dob'];
$mob=$_REQUEST['mob'];
$email=$_REQUEST['email'];
$pass=$_REQUEST['pass'];

$query="INSERT INTO `details` VALUES ('','$fname','$lname','$dob','$mob','$email','$pass')";

$sql=mysqli_query($con,$query);

if ($sql) {
	
	return "this";
}
else {
	echo "data not insert";
}




?>