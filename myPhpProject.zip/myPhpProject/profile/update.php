<?php 


?>
<!DOCTYPE html>
<html>
	<head>
		<title>Update</title>
		<?php
			include_once('conn.php');
			include_once('links.php');
		?>
		<style type="text/css" media="screen">
			.error{
				display: none;
				margin-left: 10px;
			}		

			.error_show{
				color: red;
				margin-left: 10px;
			}
			input[type=text].invalid{
				border: 2px solid red;
			}

			input[type=text].valid{
				border: 2px solid green;
			}
			.myBtn{
				opacity: 0.5;
			}
		</style>
	</head>
	<body id="body">
		<?php
			
			if (isset($_POST['email']) && isset($_POST['password'])) {
				
				$id=$_POST['id'];
				$fname=$_POST['fname'];
				$lname=$_POST['lname'];
				$dob=$_POST['date'];
				$mob=$_POST['mno'];
				$email=$_POST['email'];
				$passSimple=$_POST['password'];
				$pass=md5($passSimple);

				
				$targetPath="img/".$_FILES['img']['name'];;
				$sourcePath=$_FILES['img']['tmp_name'];
				

					$query="UPDATE `details` SET `fname`='$fname',`lname`='$lname',`bdate`='$dob',`mno`='$mob',`email`='$email',`password`='$pass',`img`='$targetPath' where id='$id'";

					$sql=mysqli_query($con,$query);

					if ($sql) {
						$filePath=move_uploaded_file($sourcePath, $targetPath);
						
						header("location:home.php");
					}
					else {
						?>
							<script>
								alert('Data not Insert !');
								window.location.href='update.php';
							</script>
						<?php
					}
					
				

			}
			else{
		?>
		<div class="container login-container">
			<?php 
				$id = intval($_GET['id']);
				$query="SELECT * FROM `details` WHERE id='$id'";
				$result=mysqli_query($con,$query);

				$row=mysqli_fetch_array($result);
			?>
			<div class="row">
				<div class="offset-2 col-md-8 login-form-1">
					<div class="d-flex flex-row justify-content-around">
						<h3>Update Record</h3>
						<a href="home.php" class="btn btn-primary">Back</a>
					</div>
					
					<form method="post" action="update.php" id="contact" enctype="multipart/form-data">
						<div class="form-group">
							<div class="d-flex justify-content-around">
								<input type="hidden" id="id" name="id" class="form-control" pattern="[a-zA-Z]{2,15}"  value="<?php echo $row['id']; ?>" required 

								/>
								
							</div>
						<div class="form-group">
							<div class="d-flex justify-content-around">
								<label for="first_name" >First Name</label>
								<input type="text" id="first_name" name="fname" class="form-control" pattern="[a-zA-Z]{2,15}" placeholder="First Name" value="<?php echo $row['fname']; ?>" required 

								/>
								
							</div>
							<div class="d-flex justify-content-end" style="padding-top: 5px;margin-right: 10%;">
								
								<span class="error" id="f_name">Name will alphabet only</span>
							</div>
						</div>
						<div class="form-group">
							<div class="d-flex justify-content-around">
								<label for="last_name" >Last Name</label>
								<input type="text" id="last_name" name="lname" class="form-control" pattern="[a-zA-Z]{2,15}" placeholder="First Name" value="<?php echo $row['lname']; ?>" required
								/>
							</div>
							<div class="d-flex justify-content-end" style="padding-top: 5px;margin-right: 10%;">
								
								<span class="error" id="l_name">Name will alphabet only</span>
							</div>
						</div>
						<div class="form-group">
							<div class="d-flex justify-content-around">
								<label for="" >Date of Birth</label>
								<input type="date" id="date" name="date" class="form-control" placeholder="Date of Birth" value="<?php echo $row['bdate']; ?>" required onchange="myDate()" />
							</div>
							<div class="d-flex justify-content-end" style="padding-top: 5px;margin-right: 10%;">
								
								<span class="error" id="d_name">Your age is less than 18</span>
							</div>
						</div>
						<div class="form-group">
							<div class="d-flex justify-content-end" style="padding-top: 5px;margin-right: 5%;">
								<span class="error" id="m_name" style="margin-right: 10%;">Type integer value only</span>
								<span><span id="m_length">11</span> Digits Remaining</span>
							</div>
							<div class="d-flex justify-content-around">
								<label for="mob_no" >Mobile No</label>
								<input type="text" id="mob_no" name="mno" class="form-control" placeholder="Enter Mobile No" value="<?php echo $row['mno']; ?>"  maxlength="11" required />
							</div>
							<div class="d-flex justify-content-end" style="padding-top: 5px;margin-right: 10%;">
								
								
							</div>
						</div>
						<div class="form-group">
							<div class="d-flex justify-content-end" style="padding-top: 5px;margin-right: 5%;">
								<span class="error" id="m_email" style="margin-right: 10%;">Please type valid email</span>
								
							</div>
							<div class="d-flex justify-content-around">
								<label for="email" >Email</label>
								<input type="email" id="email" name="email" class="form-control" placeholder="Enter Email" value="<?php echo $row['email']; ?>" required />
							</div>
						</div>
						<div class="form-group">
							<div class="d-flex justify-content-around">
								<label for="password" >Password</label>
								<input type="password" id="password" name="password" class="form-control" required placeholder="Enter Password" value="<?php echo $row['password']; ?>"
								pattern="[A-Za-z0-9@]{8,15}"
								/>
								
							</div>
							<div class="d-flex justify-content-end" style="padding-top: 5px;margin-right: 10%;">
								
								<span style="color: gray; margin-right: 8%;">Like: aB3h@3rc</span>
								<span id='hint'></span>
							</div>
						</div>
						<div class="form-group">
							<div class="d-flex justify-content-around">
								<label for="confirm_password" >Confirm Password</label>
								<input type="password" id="confirm_password" name="confirm_password" class="form-control" required placeholder="Confirm Password" value="<?php echo $row['password']; ?>" />
								
							</div>
							<div class="d-flex justify-content-end" style="padding-top: 5px;margin-right: 8%;">
								<span id='message'></span>
							</div>
						</div>
						<div class="form-group">
							<div class="d-flex justify-content-around">
								<label for="img" >Upload image</label>
								<input type="file" id="img" name="img" class="form-control" required   />
								
							</div>
							<!-- <div class="d-flex justify-content-end" style="padding-top: 5px;margin-right: 8%;">
								<span id='message'></span>
							</div> -->
						</div>
						<div class="form-group">
							<div class="d-flex justify-content-around">
								<img id="blah" src="#" alt="your image" width="100" class="round" />
							</div>
							<!-- <div class="d-flex justify-content-end" style="padding-top: 5px;margin-right: 8%;">
								<span id='message'></span>
							</div> -->
						</div>
						<div class="form-group">
							<div class="d-flex justify-content-around">
								<input type="submit"  id="submit" onclick="showHint()" disabled class="btnSubmit myBtn" value="Update"  />
								
							</div>
							
						</div>
						
					</form>
					
					
				</div>
				
			</div>
		</div>
		<!--script here-->
		<script  >
			
			$flag=false;
			$flg=false;
			$check='';

			var maxLength = 11;
			$('#mob_no').on('keyup mouseover',function() {
			  var textlen = maxLength - $(this).val().length;
			  $('#m_length').text(textlen).css('color','red');
			});

			function myDate(){
				var Bdate=$('#date').val().toString().substring(0, 4);
				

				var d = new Date();
				var date = d.getDate();
				var month = d.getMonth() + 1; // Since getMonth() returns month from 0-11 not 1-12
				var year = d.getFullYear();

				var totalAge=parseInt(year)-parseInt(Bdate);
				
				if (totalAge > '18') {
					
					$flg=true;
					$('#d_name').addClass("error").removeClass("error_show");
					this.removeClass("invalid").addClass("valid");
					
				}
				else{
					
					$flg=false;
					$('#d_name').removeClass("error").addClass("error_show");
					this.removeClass("valid").addClass("invalid");
					
				}

				
			}
			/*form field validation start*/
				$('#first_name,#last_name,#mob_no,#email').on('keyup',function(){
					var chkAtr=$(this).attr('id');
					var fname=$(this).val();
					var letters = /^[A-Za-z]+$/;
					var numbers = /^[0-9]+$/;
					if (chkAtr=='first_name') {
						if(fname.match(letters))
					      {
					      	$('#f_name').addClass("error").removeClass("error_show");
					      	this.removeClass("invalid").addClass("valid");
					      	return true;
					      }
					      else
					      {
					      	$('#f_name').removeClass("error").addClass("error_show");
					      	this.removeClass("valid").addClass("invalid");
					      return false;
					      }
					}
					else if (chkAtr=='last_name'){
						if(fname.match(letters))
					      {
					      	$('#l_name').addClass("error").removeClass("error_show");
					      	this.removeClass("invalid").addClass("valid");
					      	return true;
					      }
					      else
					      {
					      	$('#l_name').removeClass("error").addClass("error_show");
					      	this.removeClass("valid").addClass("invalid");
					      return false;
					      }
					}
					else if (chkAtr=='mob_no'){

						if(fname.match(numbers) && fname.length < '12')
					      {
					      	
					      	$('#m_name').addClass("error").removeClass("error_show");
					      	this.removeClass("invalid").addClass("valid");
					      	return true;
					      }
					      else
					      {
					      	
					      	$('#m_name').removeClass("error").addClass("error_show");
					      	this.removeClass("valid").addClass("invalid");
					      return false;
					      }
					}
					else if (chkAtr=='email'){
							var email=$(this).val();
							var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
							 if(!regex.test(email)) {
						  		$('#m_email').removeClass("error").addClass("error_show");
					      		this.removeClass("valid").addClass("invalid");
					        	
					        }else{
					        	
					        	$('#m_email').addClass("error").removeClass("error_show");
					      		this.removeClass("invalid").addClass("valid");
				
					        }
					     
						
					}
				});
			/*form field validation start*/

			$('#password, #confirm_password').on('keyup', function () {
				var pass=$('#password').val();
				if ((pass.length >='0') && (pass.length <='4')) {
						$('#hint').html('Week').css('color', 'red');
				}
				else if((pass.length >'4') && (pass.length <='7')){
					$('#hint').html('Now Average').css('color', 'gray');
				}
				else if((pass.length >'7') ){
					$('#hint').html('Now Strong').css('color', 'green');
				}

				if ($('#password').val() == $('#confirm_password').val()) {
					

					if (pass.length >= '8') {
						$('#message').html('Password Matched').css('color', 'green');
						$flag=true;
						
					}
					
				} 
				else{
					$('#message').html('Write Same Password').css('color', 'red');
					$flag=false;
				}
					
			});
			/*$('#submit').click(function(){
			
			});*/
			function showHint(){
				$('input').each(function() {
					if(!$(this).val()){
					alert('Please fill all fields!');
					exit;
					}
				});

				
				/*if ($flag==true){
					var fName=$("#fname").val();
						var lName=$("#lname").val();
						var dob=$("#date").val();
						var mob=$("#mno").val();
						var email=$("#email").val();
						var pass=$("#password").val();
						
						var xmlhttp = new XMLHttpPOST();
					xmlhttp.onreadystatechange = function() {
					if (this.readyState == 4 && this.status == 200) {
					$check = this.responseText;
					
					}
					};
					xmlhttp.open("POST", "insert.php?fName=" + fName + "&lName=" + lName + "&dob="  + dob + "&mob=" + mob + "&email=" + email + "&pass=" + pass, true);
					xmlhttp.send();
				}*/
				
		
			}
			/******script for imgae show on form******/
			function readURL(input) {

			    if (input.files && input.files[0]) {
			        var reader = new FileReader();

			        reader.onload = function (e) {
			            $('#blah').attr('src', e.target.result);
			        }

			        reader.readAsDataURL(input.files[0]);
			    }
			}

			$("#img").change(function(){
			    readURL(this);
			});
			/*******img show script end********/

			$('#contact').on('keyup mouseover', function(){
				if ($flag==false && $flg==false) {
					$('.btnSubmit').removeAttr('disabled');
					$('.btnSubmit').removeClass('myBtn');
				}
			});

			

		</script>
		<?php
		}
		?>
		
	</body>
</html>

<?php

?>

