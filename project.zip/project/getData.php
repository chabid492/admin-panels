<?php
include('config/config.php');

$departid = $_POST['depart'];   // department id

$sql = "SELECT * FROM model WHERE make_id='$departid'";

$result = mysqli_query($con,$sql);

while( $row = mysqli_fetch_array($result) ){
    $userid = $row['id'];
    $name = $row['model_name'];

    $users_arr[] = array("id" => $userid, "name" => $name);
}

// encoding array to json format
echo json_encode($users_arr);
?>
