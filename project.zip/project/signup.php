<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Signup</title>
    <?php
      include('links/links.php');
      include('config/config.php');
     ?>

     </script>
     <style type="text/css">
   		body{
   			background: #EFF0F2;
   		}
   		.warn{
   			display: none;
   			color: red;
   		}
   		.card form div input{

   			width:100%;
   			padding:4px;
   		}
   		.card{
   			padding:20px;
   			border-radius: 0px;
   			border:none;
   		}

   		.btn{
   			background: #57DC05 !important;

   		}
   		.caution{
   			padding: 50px 10px;
   			/*text-align: center;*/
   			/*justify-content: center;*/
   			background: white;
   			margin-top: 30px;
   		}

   		 ul {
   			 margin: 0;
      	 padding: 0;
   			  list-style: none;
     			 /* Remove default bullets */
   		}
      .sign li{
        display: inline-block;margin-right: 13px;
        margin-left: 3px;
      }
      .circle.small {
      	border: 2px solid #A8A8A8;
      	border-radius: 50%;
      	width: 13px;
      	height: 13px;
      	z-index: 86;
        margin-top: 7px;
        display: inline-block;
      }


   		 .check{

   			background-image: url("Assets/imgs/tick.png");
   			background-position: center;
   		}
      
      .bar{
        background: #EFF0F2;
        width:100%;
        height:20px;

      }

   	</style>
  </head>
  <body>
      <?php include_once 'fixed/header.php'; ?>
      <div class="container" style="padding-top: 20px;">
    		<div class="row">
    			<div class="col-md-8">
    				<div class="card">
    					<h2>Register</h2>
    						<form>
    							<div>
    								<label>Email address</label>
    								<input type="email" name="eamil" required>
    								<p class="warn">Please enter information above</p>
    							</div>
    							<div>
    								<label>Name</label>
    								<input type="text" name="name" required>
    								<p class="warn">Please enter information above</p>
    							</div>


    						<div>
    							<label>Password(at least 8 characters)</label>
    							<input type="password" value="" name="password" id="password">
    							<div class="progress" style="height:4px;margin-top:1px;">
       								 <div class="bar" id="hint" ></div>
     							 </div>
    							<p class="warn">Please enter information above</p>
    							<div class="d-flex justify-content-around">
    								 	<ul class="sign">
                        <div class="d-flex flex-row justify-content-around myDiv">
                          <div class="d-flex justify-content-center">
                            <div class="circle small" id="upr"></div>
                            <li style="">Uppercase</li>
                          </div>

                          <div class="d-flex justify-content-center">
                            <div class="circle small" id="lwr"></div>
                            <li style="">Lowercase</li>
                          </div>

                          <div class="d-flex justify-content-center">
                            <div class="circle small" id="no"></div>
                            <li style="">Number</li>
                          </div>

                          <div class="d-flex justify-content-center">
                            <div class="circle small" id="sym"></div>
                            <li style="">Symbol</li>
                          </div>

                          <div class="d-flex justify-content-center">
                            <div class="circle small" id="chr"></div>
                            <li style="">At least 8 characters</li>
                          </div>
                        </div>
    								</ul>

    							</div>
    						</div>

    						<div>
    							<label>Retype Password</label>
    							<input type="password" value="" name="cpassword" id="confirm_password">

                  <div class="d-flex justify-content-between" style="padding-top: 5px;margin-right: 8%;">
                    <button type="submit" id="submit" onclick="showHint()" disabled class="btn btn-success">Register</button>
                        <span id='message'></span>
							     </div>
    						</div>

    						</form>
    				</div>

    			</div>
    			<div class="col-md-4">
    					<div class="card">
    						<center><h4>Already registered ?</h4></center>
    						<p>Sign in to post Post your ads</p>
    						<input type="submit" name="" value="Sign in"  class="btn btn-success">
    					</div>
    					<div class="caution">
    						<center><h5>Why Register</h5></center>
    						<p>
    							To enhance your yabie experience and help you stay safe and secure, you now need to register to:

    						</p>



    						<ul>
    							<li>Post,Edit and manage adds</li>
    							<li>Access saved ads in your Favourites from all of your devices</li>
    							<li>Reserve your own nickname</li>
    							<li>Easily promote multiple ads to gain more visibility and view order history</li>
    							<li>And much more!</li>

    						</ul>
    					</div>
    				</div>
    		</div>
    	</div>

      <script type="text/javascript">

        $flag=false;
        //checking password length and validation
      $('#password').on('keyup', function () {

				var pass=$(this).val();
        //check password's characters with regular expression and pattren
        var uletters = new RegExp('[A-Z]');
        var lletters = new RegExp('[a-z]');
        var numbers = new RegExp('[0-9]');
        var symo = /^[A-Za-z0-9 ]+$/;
        if (pass.length > 0) {
          var clr="#F8AA17";
          $('#hint').css('background-color',clr);
          if (pass.match(uletters)) {
            $('#upr').addClass('check');

          }else {
            $('#upr').removeClass('check');

          }
          if (pass.match(lletters)) {
            $('#lwr').addClass('check');

          }else {
            $('#lwr').removeClass('check');

          }
          if (pass.match(numbers)) {
            $('#no').addClass('check');

          }else {
            $('#no').removeClass('check');

          }
          if (!pass.match(symo)) {
            $('#sym').addClass('check');

          }else {
            $('#sym').removeClass('check');

          }
          if (pass.length > 7) {
            $('#chr').addClass('check');

          }else {
            $('#chr').removeClass('check');

          }

        }
        else{
          var clr="#EFF0F2";
          $('#hint').css('background-color',clr);
          $('#upr').removeClass('check');
          $('#lwr').removeClass('check');
          $('#no').removeClass('check');
          $('#sym').removeClass('check');
          $('#chr').removeClass('check');


        }

        //this function will check that all 5 div has class check or not
        $('div.myDiv').each(function() {
          if($('div.check', this).length > 4) {
            var clr="#56C17C";
            $('#hint').css('background-color',clr);
            $flag=true;
          }else if(pass.length>0){
            var clr="#F8AA17";
            $('#hint').css('background-color',clr);
            $flag=false;
          }else {
            var clr="#EFF0F2";
            $('#hint').css('background-color',clr);
            $flag=false;
          }

        });

			});

      // check that password and confirm_password are matched
        $("#password, #confirm_password").on('keyup',function () {

            var pass=$("#password").val();
            var cpass=$("#confirm_password").val();
            if ( (pass==cpass) && (pass.length > 2) && ($flag==true)) {
                $("#submit").removeAttr('disabled');
                $("#message").text("Password matched").css('color','green');
            }else {
              $("#submit").attr('disabled','disabled');
              $("#message").text("Password do not match").css('color','red');
            }
        });
        //check all fields of form on submit click
        function showHint(){
          $('input').each(function() {
            if(!$(this).val()){
            alert('Please fill all fields!');
            exit;
            }
          });
        }
      </script>
  </body>
</html>
