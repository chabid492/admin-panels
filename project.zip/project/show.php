<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Display Category</title>
    <?php
      include('links/links.php');
      include('config/config.php');
     ?>

     </script>
     <style type="text/css">
   		body{
   			background: #EFF0F2;
   		}
      #close{
        font-size: 20px;
        padding: 5px;
        color: gray;
        padding: 5px;

      }
   	</style>
  </head>
  <body>
      <?php include_once 'fixed/header.php'; ?>
      <div class="container" style="padding-top: 20px;">
    		<div class="row">
    			<div class="offset-2 col-md-8">
    				<div class="d-flex justify-content-center">
                <form class="w-50 text-center" action="" method="">
                  <div class="form-group">
                    <input type="text" class="form-control" id="usr">
                  </div>
                  <div class="form-group">
                    <button type="button" value="level1" onclick="showCat(id='', value)" class="btn btn-info btnn" class="form-control" id="btn">Next</button>
                  </div>
                </form>
            </div>
            <div >
              <ul id="clicked_cat" class="list-group mb-1" >

              </ul>
            </div>
            <div >
              <ul id="category" class="list-group" >

              </ul>
            </div>
    			</div>

    		</div>
    	</div>

      <script type="text/javascript">

          function showCat(id, level) {
                  var id = id;
                  var level=level;
                 $.ajax({
                     url: 'show-get.php',
                     type: 'post',
                     data: {id:id,level:level},
                     dataType: 'json',
                     success:function(response){

                         var len = response.length;
                         $("#category").empty();
                         for( var i = 0; i<len; i++){

                             var id = response[i].id;
                             var name = response[i].name;
                             if (level=='level1') {

                             $("#category").append("<li id='list' value='"+id+"' class='list-group-item w-100'>"+name+"</li>");
                           }else if (level=='level2'){
                                var chkPg=response[i].more_page;
                                if (chkPg==1) {
                                  $("#category").append("<li  value='"+id+"' subcat='"+response[i].mcat_id+"' class='list-group-item w-100'>"+name+"<a href='home.php' id='link' class='fa fa-angle-right' style='float:right;font-size:20px;'></a></li>");
                                }
                               $("#category").append("<li id='list2' value='"+id+"' subcat='"+response[i].mcat_id+"' class='list-group-item w-100'>"+name+"</li>");
                           }
                           else{
                             $("#category").append("<li id='list3' value='"+id+"' class='list-group-item w-100'>"+name+"<a href='home.php' id='link' class='fa fa-angle-right' style='float:right;font-size:20px;'></a></li>");
                           }

                         }
                     }
                 });
             }

             // clidked sub category show

             $(document).on('click','#list',function () {
                
               $("#clicked_cat").append("<li value='"+$(this).val()+"' id='appnd' class='list-group-item w-100 mb-1'>"+$(this).text()+"<span id='close' class='fa fa-close' style='float:right;'></span>"+"</li>");

               showCat($(this).val(),level='level2');
             });

             // clidked third category show
             $(document).on('click','#list2',function () {
                showCat($(this).val(),level='level3');
               $("#clicked_cat").append("<li value='"+$(this).val()+"' subcat='"+$(this).attr('subcat')+"' id='list3' class='list-group-item w-100'>"+$(this).text()+"<span id='close' class='fa fa-close' style='float:right;'></span>"+"</li>");
             });

             //remove an item
             $(document).on('click','.fa-close',function(event) {
              var prev="";
              var id="";
              if ($(this).parents().attr('id')=='list3') {
                  prev="level2";
                  id=$(this).parents().attr('subcat');
                  event.stopPropagation();
                  $(this).parents('#appnd,#list3').remove();
                  showCat(id,prev);
              }else{
                prev="level1";
                id='';
                event.stopPropagation();
                $('#list3').remove();
                $(this).parents('#appnd').remove();
                showCat(id,prev);
              }
              
              
            });

          //set code in document ready function when online
         $(document).ready(function(){

             

            //check whick class is clicked
         });




     </script>
  </body>
</html>
