<nav class="">
  <div class="d-flex justify-content-between nav" style="background:#54DD01;padding:14px;">
    <div>
      <img src="Assets/imgs/yabie.png">
    </div>
    <div>
      <img src="Assets/imgs/capture.png">
    </div>
  </div>
</nav>
