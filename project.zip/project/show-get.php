<?php
include('config/config.php');

 $id = $_POST['id'];   // cheking id
 $level = $_POST['level'];   // cheking id

if ($level=="level1") {
	$sql = "SELECT * FROM main_categories";
	$result = mysqli_query($con,$sql);

	while( $row = mysqli_fetch_array($result) ){
	    $userid = $row['id'];
	    $name = $row['name'];

	    $users_arr[] = array("id" => $userid, "name" => $name);
	}

	// encoding array to json format
	echo json_encode($users_arr);
}
else if($level=="level2"){

	$sql = "SELECT * FROM sub_categories WHERE mcat_id='$id'";
	$result = mysqli_query($con,$sql);

	while( $row = mysqli_fetch_array($result) ){
	    $userid = $row['id'];
	    $name = $row['name'];
	    $mcat_id = $row['mcat_id'];
	    $more_page = $row['more_page'];

	    $users_arr[] = array("id" => $userid, "name" => $name, "mcat_id" => $mcat_id, "more_page" => $more_page);
	}

	// encoding array to json format
	echo json_encode($users_arr);

}
else if($level=="level3"){
	$sql = "SELECT * FROM third_lev_cat WHERE sub_cat_id='$id'";
	$result = mysqli_query($con,$sql);

	while( $row = mysqli_fetch_array($result) ){
	    $userid = $row['id'];
	    $name = $row['name'];

	    $users_arr[] = array("id" => $userid, "name" => $name);
	}

	// encoding array to json format
	echo json_encode($users_arr);

}


?>
