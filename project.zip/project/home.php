<!DOCTYPE html>
<html>
	<head>
		<title>category</title>
		<?php
			include('links/links.php');
			include('config/config.php');
		?>

	</head>
	<body>
		<?php
			include ('fixed/header.php');
		 ?>
		<div class="container-fluid">
			<div class="title">
				<p>categories:<span class="heading">cars&vehicles/cars</span><span class="change">&nbspchange</span></p>
			</div>
			<div class="row">
				<div class="col-md-6">
					<div class="card">
						<h4>*Add title</h4>
						<input type="text" name="" class='mi-input'>
					</div>
					<div class="card">
						<h4>*Add Description</h4>
						<textarea></textarea>
					</div>
					<div class="card">
						<h4>(Optional) Tags <span>increase exposure</span></h4>
						<input type="text" name="" class="mi-input">
						<button class="btn">Add</button>
					</div>
				</div>
				<div class="col-md-6">
					<div class="mi-card">
						<table>
							<tbody>
								<tr>
									<td>

										<h6>Make</h6>
										<select id="sel_depart" name="drinks">
											<option value="0">- Select -</option>
											<?php
				                            $sql="select * from categories";
				                             $res=mysqli_query($con,$sql);
				                              while($row=mysqli_fetch_assoc($res)){
				                                  ?>
				                                    <option value="<?php echo $row['id'] ?>"><?php echo $row['name'] ?></option>
				                                  <?php
				                               }
				                             ?>
										</select>
									</td>
									<td>
										<h6 id="my">Body type</h6>
										<select name="drinks" required>
											<option value="" disabled selected>Select</option>
											<option value="coffee">Coffee</option>
											<option value="tea">Tea</option>
											<option value="milk">Milk</option>
										</select>
									</td>
									<td>
										<h6>Fuel type</h6>
										<input type="text" name="" class="mi-inputB">
									</td>
								</tr>
								<tr>
									<td>
										<h6>MOdel</h6>
										<select name="drinks" required id="sel_user">
											<option value="0">- Select -</option>

										</select>
									</td>
									<td>
										<h6>Drive line(optional)</h6>
										<select name="drinks" required>
											<option value="" disabled selected>Select</option>
											<option value="coffee">Coffee</option>
											<option value="tea">Tea</option>
											<option value="milk">Milk</option>
										</select>
									</td>

								</tr>
								<tr>
									<td>
										<h6>Year</h6>
										<input type="" class="mi-inputB" name="">
									</td>
									<td>
										<h6>Conditions</h6>
										<select name="drinks" required>
											<option value="" disabled selected>Select</option>
											<option value="coffee">Coffee</option>
											<option value="tea">Tea</option>
											<option value="milk">Milk</option>
										</select>
									</td>

								</tr>
								<tr>
									<td>
										<h6>Kilometer</h6>
										<input type="" class="mi-inputB" name="">
									</td>
									<td>
										<h6>Color(Optional)</h6>
										<select name="drinks" required>
											<option value="" disabled selected>Select</option>
											<option value="coffee">Coffee</option>
											<option value="tea">Tea</option>
											<option value="milk">Milk</option>
										</select>
									</td>

								</tr>
								<tr>
									<td>
										<h6>Transmissions</h6>
										<select name="drinks" required>
											<option value="" disabled selected>Select</option>
											<option value="coffee">Coffee</option>
											<option value="tea">Tea</option>
											<option value="milk">Milk</option>
										</select>
									</td>
									<td>
										<h6>Doors</h6>
										<select name="drinks" required>
											<option value="" disabled selected>Select</option>
											<option value="coffee">Coffee</option>
											<option value="tea">Tea</option>
											<option value="milk">Milk</option>
										</select>
									</td>

								</tr>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>

		 <script type="text/javascript">
        $(document).ready(function(){

            $("#sel_depart").change(function(){
                var deptid = $(this).val();

                $.ajax({
                    url: 'getData.php',
                    type: 'post',
                    data: {depart:deptid},
                    dataType: 'json',
                    success:function(response){
                        var len = response.length;

                        $("#sel_user").empty();
                        for( var i = 0; i<len; i++){

                            var id = response[i].id;
                            var name = response[i].name;

                            $("#sel_user").append("<option value='"+id+"'>"+name+"</option>");

                        }
                    }
                });


            });

        });
    </script>
	</body>
</html>
