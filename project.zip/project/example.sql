-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 12, 2020 at 12:47 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `example`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(1, 'Coffee'),
(2, 'Tea'),
(3, 'Milk');

-- --------------------------------------------------------

--
-- Table structure for table `main_categories`
--

CREATE TABLE `main_categories` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `main_categories`
--

INSERT INTO `main_categories` (`id`, `name`) VALUES
(1, 'Buy and Sell'),
(2, 'Bikes'),
(3, 'Books'),
(4, 'iPad'),
(5, 'Speeker');

-- --------------------------------------------------------

--
-- Table structure for table `model`
--

CREATE TABLE `model` (
  `id` int(255) NOT NULL,
  `make_id` varchar(255) NOT NULL,
  `model_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `model`
--

INSERT INTO `model` (`id`, `make_id`, `model_name`) VALUES
(1, '1', 'Coffe model 1'),
(2, '1', 'Coffe model 2'),
(3, '1', 'Coffe model 3'),
(4, '1', 'Coffe model 4'),
(5, '2', 'Tea model1'),
(6, '3', 'Milk model 1'),
(7, '3', 'Milk model 2');

-- --------------------------------------------------------

--
-- Table structure for table `sub_categories`
--

CREATE TABLE `sub_categories` (
  `id` int(11) NOT NULL,
  `mcat_id` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `more_page` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sub_categories`
--

INSERT INTO `sub_categories` (`id`, `mcat_id`, `name`, `more_page`) VALUES
(1, '1', 'Buy and Sell sub cat 1', 1),
(2, '1', 'Buy and Sell sub cat 2', 0),
(3, '1', 'Buy and Sell sub cat 3', 1),
(4, '1', 'Buy and Sell sub cat 4', 1),
(5, '2', 'Bike cat 1', 1),
(6, '2', 'Bike cat 2', 1),
(7, '2', 'Bike cat 3', 0),
(8, '2', 'Bike cat 4', 1),
(9, '3', 'Books cat 1', 0),
(10, '4', 'ipad cat 1', 0),
(11, '5', 'speaker cat 1', 1);

-- --------------------------------------------------------

--
-- Table structure for table `third_lev_cat`
--

CREATE TABLE `third_lev_cat` (
  `id` int(255) NOT NULL,
  `sub_cat_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `third_lev_cat`
--

INSERT INTO `third_lev_cat` (`id`, `sub_cat_id`, `name`) VALUES
(1, '1', 'Buy and sel third lev 3'),
(2, '1', 'Buy and sel third lev 3'),
(3, '5', 'bike 1 cat lev 3'),
(4, '6', 'bike 6 cat lev 3'),
(5, '6', 'bike 6 cat lev 3'),
(6, '9', 'book level3'),
(7, '2', 'Buy and Sell sub cat 3\r\n'),
(8, '3', 'Buy and Sell sub cat 3'),
(9, '4', 'Buy and Sell sub cat 3\r\n'),
(10, '7', 'Bike cat 3'),
(11, '8', 'Bike cat 3'),
(12, '10', '	\r\nipad cat 3'),
(13, '11', 'speaker cat 3');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `main_categories`
--
ALTER TABLE `main_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `model`
--
ALTER TABLE `model`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sub_categories`
--
ALTER TABLE `sub_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `third_lev_cat`
--
ALTER TABLE `third_lev_cat`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `main_categories`
--
ALTER TABLE `main_categories`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `model`
--
ALTER TABLE `model`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `sub_categories`
--
ALTER TABLE `sub_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `third_lev_cat`
--
ALTER TABLE `third_lev_cat`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
